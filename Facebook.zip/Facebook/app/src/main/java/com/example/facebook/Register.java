package com.example.facebook;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.widget.TextView;

public class Register<myFirstName> extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d("Activity_lifecycle", "onCreate:");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        EditText firstName = (EditText)findViewById(R.id.editTextTextPersonName4);
        String myFirstName = firstName.getEditableText().toString();
        Button log = findViewById(R.id.button);
        log.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Your Name is : " + myFirstName,Toast.LENGTH_LONG).show();
            }
        });
    }
}